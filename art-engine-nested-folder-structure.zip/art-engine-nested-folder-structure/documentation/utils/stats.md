# Stats

### 🧪In development

Similar to rarity, with the main difference being `stats` will output the number of times an image file was used (not the ending attribute trait\_type & value) which gives you visibility into how the weight of each file affected the current run of the generator. \
\
This is very useful if you have a low weight set for a rare image and you want to be sure it is being used (not, zero)


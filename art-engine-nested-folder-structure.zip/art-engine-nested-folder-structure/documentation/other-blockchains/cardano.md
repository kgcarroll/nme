# Cardano

`yarn generate:cardano`

details coming soon, see the readme.md
